/*
I assume a command line like this:

>firefox -print http://www.example.com/ -printmode PDF -printfile foo.pdf

Nontheless, 

>firefox -print http://www.example.com/
or
>firefox -print http://www.example.com/ -printmode PNG

should work.

-print <URL> @required.
-printmode <mode> @optional
-printfile <file> @optional

<URL>: URL string.
<mode> is either "printer", "pdf" or "png". case-incensitive.
<file> is relative path from current directory where you are typing command.

*/

/*
   Default mode. 
   This value applied when -printmode argument is not set.

   0 : Printer
   1 : PDF
   2 : PNG

 */
pref("extensions.cmdlnprint.mode", 0);

/*
   When the mode is either PDF or PNG, and -printfile was not set,

   %EXT% is a file extension, either "pdf" or "png", which
   depends on the mode; -printmode param or "extensions.cmdlnprint.mode".

   %DATE% is "YYYYMMDD-hhmmss+TIMZONE"

   %HOST% is host of target URI. Note that the target may be redirected.
   so %HOST% is not always equals to the URI you specified with -print command.
 */
pref("extensions.cmdlnprint.basefilename",
     "%TITLE%@%HOST%_%DATE%.%EXT%");
